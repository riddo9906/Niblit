"""Configuration helpers for modules."""

